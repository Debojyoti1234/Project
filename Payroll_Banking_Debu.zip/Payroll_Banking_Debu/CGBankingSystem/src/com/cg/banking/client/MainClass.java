package com.cg.banking.client;

import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

public class MainClass {

	public static void main(String[] args) {
		long accNo,accNoFrom,accNoTo;
		int pinNo;
		float amt;
		
		BankingServices services=new BankingServicesImpl();
	Account customer1=null;
	Account customer2=null;
	try {
		customer1=services.openAccount("Savings",2000);
		customer1.setAccountStatus("Active");
		
	}catch(InvalidAccountTypeException|InvalidAmountException|BankingServicesDownException e) {
		e.printStackTrace();
	}
	try {
		customer2=services.openAccount("Current",5000);
		customer2.setAccountStatus("Active");
		
	}catch(InvalidAccountTypeException|InvalidAmountException|BankingServicesDownException e) {
		e.printStackTrace();
	}
	
	System.out.println("Account details: "+customer1);
	System.out.println("Account details:"+customer2);
	Scanner sc=new Scanner(System.in);
	System.out.println("------------------Withdraw---------------");
	System.out.println("Enter Account no:");
	accNo=sc.nextLong();
	System.out.println("Enter pin no:");
	pinNo=sc.nextInt();
	System.out.println("Enter amount to withdraw");
	amt=sc.nextFloat();
	try {
		System.out.println(services.withdrawAmount(accNo,amt,pinNo));
		System.out.println("Account details after withdrawl"+services.getAccountDetails(accNo));
	}catch(InsufficientAmountException|AccountNotFoundException|InvalidPinNumberException|BankingServicesDownException|AccountBlockedException e) {
	e.printStackTrace();
	}
	System.out.println("------------------Deposit---------------");
	System.out.println("Enter Account no:");
	accNo=sc.nextLong();
	System.out.println("Enter ammount to deposit:");
	amt=sc.nextFloat();
	try {
		System.out.println(services.depositAmount(accNo,amt));
		System.out.println("Account details after deposit"+services.getAccountDetails(accNo));
	}catch(AccountNotFoundException|BankingServicesDownException|AccountBlockedException e) {
	e.printStackTrace();
	}
	System.out.println();
	System.out.println("----------------FundTransfer--------------");
	System.out.println("Enter account no from where u want to withdraw");
	accNoFrom=sc.nextLong();
	System.out.println("enter pin  number");
	pinNo=sc.nextInt();
	System.out.println("enter account no where to deposit:");
	accNoTo=sc.nextLong();
	System.out.println("enter transfer amount");
	amt=sc.nextFloat();
	try {
		System.out.println("fund transfer status:"+services.fundTransfer(accNoTo,accNoFrom,amt,pinNo));
		System.out.println("account details after fund transfer: \n"+services.getAccountDetails(accNoTo)+"\n"+"\n(from\n)"+services.getAccountDetails(accNoFrom));
	}
	catch(InsufficientAmountException|AccountNotFoundException|InvalidPinNumberException|BankingServicesDownException|AccountBlockedException e) {
		e.printStackTrace();
	}
	sc.close();
	}
}
