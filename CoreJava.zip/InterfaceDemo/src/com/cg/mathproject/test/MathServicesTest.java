package com.cg.mathproject.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.mathproject.exceptions.NegetiveNumberException;
import com.cg.mathproject.services.MathServices;
import com.cg.mathproject.services.MathServicesImpl;
import org.junit.*;
public class MathServicesTest {
private static MathServices services;
@BeforeClass
	public static void setUpTestEnv() {
	 services=new MathServicesImpl();
 }
	@Test(expected=NegetiveNumberException.class)
	public void testAddForFirstNumberInvalid() throws NegetiveNumberException {
	services.add(-100,200);
	}
	@Test(expected=NegetiveNumberException.class)
	public void testAddForSecondNumberInvalid() throws NegetiveNumberException {
	services.add(100,-200);
	}
	@Test
	public void testAddForBothNumberValid() throws NegetiveNumberException {
	Assert.assertEquals(300,services.add(100,200));
	}
	
	
	@Test(expected=NegetiveNumberException.class)
	public void testSubForFirstNumberInvalid() throws NegetiveNumberException {
	services.sub(-100,200);
	}
	@Test(expected=NegetiveNumberException.class)
	public void testSubForLastNumberInvalid() throws NegetiveNumberException {
	services.sub(100,-200);
	}
	@Test
	public void testSubForbothNumbervalid() throws NegetiveNumberException {
	Assert.assertEquals(100,services.sub(200,100));
	}
	
	
	@Test(expected=NegetiveNumberException.class)
	public void testDivForFirstNumberInvalid() throws NegetiveNumberException {
	services.div(-100,200);
	}
	@Test(expected=NegetiveNumberException.class)
	public void testDivForLastNumberInvalid() throws NegetiveNumberException {
	services.div(100,-200);
	}
	@Test
	public void testDivForBothNumbervalid() throws NegetiveNumberException {
		Assert.assertEquals(2,services.div(200,100));
	}
	@Test(expected=NegetiveNumberException.class)
	public void testMultiForFirstNumberInvalid() throws NegetiveNumberException {
	services.multi(-100,200);
	}
	@Test(expected=NegetiveNumberException.class)
	public void testMultiForLastNumberInvalid() throws NegetiveNumberException {
	services.multi(100,-200);
	}
	@Test
	public void testMultiForBothNumbervalid() throws NegetiveNumberException {
		Assert.assertEquals(12,services.multi(2,6));
	}
	@AfterClass
	public static void tearDownTest()
	{
		services=null;
	}
	
}
