package com.cg.mathproject.services;

public class MainClass {

	public static void main(String[] args) {
		
MathServices services=new MathServicesImpl();
	}

}
