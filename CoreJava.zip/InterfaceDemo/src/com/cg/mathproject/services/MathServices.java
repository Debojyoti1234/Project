package com.cg.mathproject.services;

import com.cg.mathproject.exceptions.NegetiveNumberException;

public interface MathServices {
	public int add(int n1,int n2) throws NegetiveNumberException;
	abstract int sub(int n1,int n2)throws NegetiveNumberException;
	public abstract int div(int n1,int n2)throws NegetiveNumberException;
	int multi(int n1,int n2)throws NegetiveNumberException;
}
