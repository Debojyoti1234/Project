package com.cg.payroll.client;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.PayrollDBUtil;
public class MainClass {
	public static void main(String[] args) throws AssociateDetailNotfoundException {
		PayrollServices services=new PayrollServicesImpl();
		int associateId1=services.acceptAssociateDetails("biki", "basu","biki@gmail.com","Student","Analyst","abc1234",10000,400000,12000,12000,100050,"citi bank","cit123456");
		int associateId=services.acceptAssociateDetails("Debojyoti", "basu","debojyoti@gmail.com","Student","Analyst","abc1234",10000,450000,12000,12000,100050,"citi bank","cit123456");
		int associateId2=services.acceptAssociateDetails("puja", "basu","debojyoti@gmail.com","Student","Analyst","abc1234",10000,750000,12000,12000,100050,"citi bank","cit123456");
		
		try {
		     System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()/*services.getAssociateDetails(associateId)*/+"   --->Net Annual salary : "+services.calculateNetSalary(associateId));
		     double monNetSalary=(services.calculateNetSalary(associateId))/12;
		     System.out.println("---->monthly net salary: "+monNetSalary);
		    
		     
		     System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()+"    --->Net Annual salary: "+services.calculateNetSalary(associateId1));
		    double monNetSalary1=(services.calculateNetSalary(associateId1))/12;
		    System.out.println("------>monthly net salary: "+monNetSalary1);
		    
		    System.out.print("Associate Id "+PayrollDBUtil.getASSOCIATE_ID_COUNTER()+"    --->Net Annual salary: "+services.calculateNetSalary(associateId2));
		    double monNetSalary2=(services.calculateNetSalary(associateId2))/12;
		    System.out.println("------>monthly net salary: "+monNetSalary2);
		}
		catch(AssociateDetailNotfoundException e)
		{
			e.printStackTrace();
		}
	}

}
