package com.cg.payroll.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.omg.CORBA.PUBLIC_MEMBER;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailNotfoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

public class PayrollServicesTestEasyMock {
private static PayrollServices payrollServices;
private static AssociateDAO mockAssociateDao;
@BeforeClass
public static void setUpTestEnv() {
	mockAssociateDao=EasyMock.mock(AssociateDAO.class);
	payrollServices=new PayrollServicesImpl(mockAssociateDao);
}
@Before
public void setUpTestMockData() {
	Associate associate1 = new Associate(101,10000,"biki", "basu", "Student","Analyst","abc1234","biki@gmail.com",
			new Salary(400000,12000,12000), new BankDetails(100050,"citi bank","cit123456"));
	Associate associate2=new Associate(102,10000,"Debojyoti", "basu", "Student","Analyst","abc1234","debojyoti@gmail.com",
			new Salary(400000,12000,12000), new BankDetails(100051,"citi bank","cit123456"));
	Associate associate3=new Associate(103,10000,"puja", "basu", "Student","Analyst","abc1234","puja@gmail.com",
			new Salary(500000,12000,12000), new BankDetails(100052,"citi bank","cit123456"));
	
	ArrayList<Associate> associatesList=new ArrayList<>();
	associatesList.add(associate1);
	associatesList.add(associate2);
	
	EasyMock.expect(mockAssociateDao.save(associate1)).andReturn(associate1);
	
	EasyMock.expect(mockAssociateDao.findOne(101)).andReturn(associate1);
	EasyMock.expect(mockAssociateDao.findOne(102)).andReturn(associate2);
	EasyMock.expect(mockAssociateDao.findOne(1234)).andReturn(null);
	EasyMock.expect(mockAssociateDao.findAll()).andReturn(associatesList);
	EasyMock.replay(mockAssociateDao);
}
@Test(expected=AssociateDetailNotfoundException.class)
public void testGetAssociateDataForInvalidAssociateId()throws AssociateDetailNotfoundException{
	payrollServices.getAssociateDetails(1234);
	EasyMock.verify(mockAssociateDao.findOne(1234) );
}
@Test
public void testGetAssociateDataForValidAssociateId()throws AssociateDetailNotfoundException{
Associate expectedAssociate=new Associate(101,10000,"biki", "basu", "Student","Analyst","abc1234","biki@gmail.com",
		new Salary(400000,12000,12000), new BankDetails(100050,"citi bank","cit123456"));
Associate actualAssociate=payrollServices.getAssociateDetails(101);
assertEquals(expectedAssociate, actualAssociate);
EasyMock.verify(mockAssociateDao.findOne(101));
}
@After
public void tearDownTestMockData() {
	EasyMock.resetToDefault(mockAssociateDao);}
@AfterClass
public static void tearDownTestEnv() {
	mockAssociateDao=null;
	payrollServices=null;
}
}
