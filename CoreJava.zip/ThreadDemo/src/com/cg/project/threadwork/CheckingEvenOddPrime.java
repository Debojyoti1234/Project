package com.cg.project.threadwork;

public class CheckingEvenOddPrime implements Runnable{

	@Override
	public void run() {
		int flag=1;
		Thread t=Thread.currentThread();
				for(int i=1;i<=100;i++) {
					if(i%2==0)
						System.out.println("Even      "+i);
					else
						System.out.println("Odd       "+i);
				}
				if(t.getName().equals("prime thread"))
		for(int j=2;j<=100;j++){
			flag=1;
			for(int k=1;k<=j/2;k++) {
				if(j%k==0)
					
			}
			if(flag==1)
			System.out.println("prime no:   "+j +" "+t.getName());
		}
				System.out.println("end of thread task");
	}

}
