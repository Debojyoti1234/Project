package com.cg.project.threadwork;

public class RunnableResource implements Runnable{
@Override
	public void run() {
	Thread t=Thread.currentThread();
	if(t.getName().equals("thickThread")) {
		try {
			for(int i=1;i<=10;i++) {
				System.out.println("tick     "+i+t.getName()   );
			}
		}catch(InterruptedException e) {
			e.printStackTrace();}
		}
	if(t.getName().equals("tockThread")) {
		try {
		for(int i=1;i<=10;i++) {
			Thread.sleep(1000);
			System.out.println("tick     "+i+t.getName()   );
		
		}}catch(InterruptedException e) {
			e.printStackTrace();}
		}
	System.out.println("End of Thread Task");

}
