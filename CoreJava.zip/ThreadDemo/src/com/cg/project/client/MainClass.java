package com.cg.project.client;


import com.cg.project.threadwork.CheckingEvenOddPrime;
import com.cg.project.threadwork.Customer;
import com.cg.project.threadwork.RunnableResource;

public class MainClass {

	public static void main(String[] args) throws InterruptedException {
	//CheckingEvenOddPrime num=new CheckingEvenOddPrime();
	//Thread th1=new Thread(num,"tickThread");
	//Thread th2=new Thread(num,"tickThread");
		Thread th1=new Thread(new Customer(),"rahul");
		Thread th2=new Thread(new Customer(),"anil");
		Thread th3=new Thread(new Customer(),"satish");
		
	th1.start();
	th1.setPriority(Thread.MAX_PRIORITY);
	//th1.join();
	th2.start();
	th3.start();
	//System.out.println("main thread end here");
	}

}
