package com.cg.hotelbooking.beans;

public class Hotel {

}
