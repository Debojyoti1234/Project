package com.cg.hotelbooking.beans;

public class BillingDetails {
private int amount;
private int cGst;
private int sgst;

}
