package com.cg.hotelbooking.beans;

public class Date {

}
