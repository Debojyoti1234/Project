
public class MainClass {

	public static void main(String[] args) {
		
int num=100;
Integer iob=num;
iob=num+iob+iob+500;
num= iob-100;
System.out.println(iob);
System.out.println(num);
}

}
