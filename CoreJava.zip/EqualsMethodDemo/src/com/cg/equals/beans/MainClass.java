package com.cg.equals.beans;

public class MainClass {

	public static void main(String[] args) {
		 
		Employee emp1=new Employee(111,"Debojyoti","Basu",12000);
		Employee emp2=new Employee(111,"Debojyoti","Basu",12000);
		if(emp1==emp2)
		{
			System.out.println("same");
		}
		else
		{
			System.out.println("not same");
	    }
		if(emp1.equals(emp2))
		{
			
			System.out.println("same");
		}
		else
		{
			System.out.println("not same");
	    }

	}

}
