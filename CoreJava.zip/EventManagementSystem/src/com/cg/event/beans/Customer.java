package com.cg.event.beans;

public class Customer {

}
