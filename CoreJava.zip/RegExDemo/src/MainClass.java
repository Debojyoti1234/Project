
public class MainClass {

	public static void main(String[] args) {
		

	}
	public static void method2{
		String str="Hello welc34866ome"
	}

}
