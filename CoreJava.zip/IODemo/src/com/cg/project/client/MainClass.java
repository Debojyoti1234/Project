package com.cg.project.client;

import java.io.File;
import java.io.IOException;
import java.util.concurrent.locks.ReadWriteLock;

import com.cg.project.beans.SerializationDemo;
import com.cg.project.readwritework.ReadWrteWork;

public class MainClass {

	public static void main(String[] args) throws ClassNotFoundException {
		try {
		/*	File fileFrom = new File(".//resources//project.properties");
			ReadWrteWork.propertiesWork(fileFrom);
		File fileFrom = new File("d:\\ciSesson.txt");
			File fileTo=new  File("c:\\temp\\"+fileFrom.getName());
			ReadWriteWork.byteStreamReadWrite(fileFrom);
			/*if(!file.exists()) {
				file.createNewFile();
			}
			System.out.println(file.canWrite());
			System.out.println(file.canExecute());
			System.out.println(file.getName());
			System.out.println(file.getAbsolutePath());
			System.out.println(file.getPath());
			System.out.println(file.length());*/
		
		File file=new File("d:\\CustomerData.txt");
		SerializationDemo.doSerialization(file);
		SerializationDemo.doDeSerialization(file);
		}catch(IOException |ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

}
