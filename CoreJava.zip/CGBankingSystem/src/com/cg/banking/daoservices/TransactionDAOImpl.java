package com.cg.banking.daoservices;

import java.util.List;

import com.cg.banking.beans.Transaction;
import com.cg.banking.util.BankingDBUtil;

public class TransactionDAOImpl implements TransactionsDAO{

	@Override
	public Transaction save(long accountNo, Transaction transaction) {
		transaction.setTransactionId(BankingDBUtil.getTRANSACTRANSACTION_ID());
		BankingDBUtil.accountDetails.get(accountNo).getTransactions().put(transaction.getTransactionId(),transaction);
		
		return null;
	}

	@Override
	public boolean update(Transaction transaction) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Transaction findOne(int transactionId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
