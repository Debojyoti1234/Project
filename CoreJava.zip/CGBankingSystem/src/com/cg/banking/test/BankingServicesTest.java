package com.cg.banking.test;

import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingDBUtil;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class BankingServicesTest {
	private static BankingServices services;

	@BeforeClass
	public static void setUpTestEnv() {
		services = new BankingServicesImpl();
	}
	@Before
	public void setUpTestData() {
		Account account1=new Account(10001, "Savings", "Active", 5000);
		Account account2=new Account(10002, "Savings", "Active", 5000);


		//	Transaction transaction1=new Transaction(101, 3000, "withdraw");
		//Transaction transaction2=new Transaction(102, 2000, "deposit");
		BankingDBUtil.accounts.put(account1.getAccountNo(), account1);
		BankingDBUtil.accounts.put(account2.getAccountNo(), account2);
		/*BankingDBUtil.accounts.put(transaction1.getTransactionId(),  transaction1);
		BankingDBUtil.accounts.put(transaction2.getTransactionId(), transaction2);*/
		BankingDBUtil.ACCOUNT_ID_COUNTER=10002;
		//BankingDBUtil.TRANSACTION_ID_COUNTER=1001;
	}
	@Test(expected=AccountNotFoundException.class)
	public void testGetAccountDetailsForInvalidAccountNumber() throws AccountNotFoundException, BankingServicesDownException{
		services.getAccountDetails(1234);	
	}
	@Test
	public void testGetAccountDetailsForValidAccountNumber()throws AccountNotFoundException, BankingServicesDownException{
		Account account1=new Account(10001, "Savings", "Active", 5000);
		Account actualAccount=services.getAccountDetails(10001);
		Assert.assertEquals(account1, actualAccount);
	}
	@Test
	public void testAcceptAccountDetailsForValiddata() throws AccountNotFoundException, BankingServicesDownException {
		int expectedAccountNumber=10001;
		Account actualAccountNumber=services.getAccountDetails(10001);
	}
	@Test
	public void testGetAllAccountDetails() throws BankingServicesDownException {
		Account account101=new Account(10001, "savings", "Active", 5000);
		Account account102=new Account(10002, "savings", "Active", 5000);

		ArrayList<Account> expectedAccountList = new ArrayList<>();
		expectedAccountList.add(account101);
		expectedAccountList.add(account102);
		ArrayList<Account> actualAccountList = (ArrayList<Account>) services.getAllAccountDetails();
		Assert.assertEquals(expectedAccountList,actualAccountList);
	}
	@Test
	public void testForOpenAccountDetailsForValidData() throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Assert.assertEquals(10003, services.openAccount("savings", 5000).getAccountNo());

	}
	@Test
	public void testDepositDetailsForValidAccount() throws AccountNotFoundException, BankingServicesDownException, AccountBlockedException {
		services.depositAmount(10002, 2000);
	}
	@Test
	public void testWithdrawDetailsForValidAccount() throws InsufficientAmountException, AccountNotFoundException, InvalidPinNumberException,
	BankingServicesDownException, AccountBlockedException {
		services.withdrawAmount(10001, 1000);
	}
	@Test
	public void testDepositDetailsForValidPin() throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, 
	AccountNotFoundException, AccountBlockedException {
		Account deposit=new Account(10001, 1234, "Savings", "Active", 7000);
		float actualAccount=services.depositAmount(10001, 2000);
 	}
	@Test
	public void testWithdrawDetailsForValidPin() throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, 
	AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		Account withdraw=new Account(10001, 1234, "Savings", "Active", 7000);
		float actualAccount=services.withdrawAmount(10001, 1000, 1234);
 	}
	@After
	public void tearDownTestData() {
		BankingDBUtil.account.clear();
		BankingDBUtil.accountNumber = 10000;
		BankingDBUtil.TRANSACTION_ID= 1000;
	}


	@AfterClass
	public static void tearDownTestEnv() {
		services = null;
	}

}