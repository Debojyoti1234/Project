package com.cg.project.collections.beans;

import java.util.HashSet;
import java.util.LinkedList;

public class LinkedListClassesDemo {
	public static void linkedListClassDemo() {
		LinkedList<Associate>associates=new LinkedList<>();
		associates.add(new Associate(111,"Debojyoti","Basu",60000));
		associates.add(new Associate(222,"Arnab","Pratihar",57000));
		associates.add(new Associate(111,"Daipayan","Guha",56000));
		associates.add(new Associate(111,"Rochita","Bagchi",55000));	
		
	} 

}
