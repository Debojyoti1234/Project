package com.cg.project.collections.beans;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;

public class ListClassesDemo {
	public static void arrayListClassDemo() {
		ArrayList<Associate>associates=new ArrayList<>();
	

		for(Associate associate:associates) {
			System.out.println(associates);
		}
		System.out.println("********************");

		Collections.sort(associates,new AssociateComparator());

		for(Associate associate:associates) {
			System.out.println(associates);

		}
	}}
