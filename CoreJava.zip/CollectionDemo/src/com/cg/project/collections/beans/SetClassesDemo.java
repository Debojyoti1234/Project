package com.cg.project.collections.beans;

import java.util.HashSet;

public class SetClassesDemo {
	public static void HashListClassDemo() {
		HashSet<Associate>associates=new HashSet<>();
		associates.add(new Associate(111,"Debojyoti","Basu",60000));
		associates.add(new Associate(222,"Arnab","Pratihar",57000));
		associates.add(new Associate(111,"Daipayan","Guha",56000));
		associates.add(new Associate(111,"Rochita","Bagchi",55000));	
}
}