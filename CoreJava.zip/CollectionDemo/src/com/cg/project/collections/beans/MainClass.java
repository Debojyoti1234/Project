package com.cg.project.collections.beans;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

public class MainClass {

	public static void main(String[] args) {


		ArrayList<Associate> strList=new ArrayList<Associate>();
		strList.add(new Associate(111,"Debojyoti","Basu",60000));
		strList.add(new Associate(222,"Arnab","Pratihar",57000));
		strList.add(new Associate(111,"Daipayan","Guha",56000));
		strList.add(new Associate(111,"Rochita","Bagchi",55000));
		
		ListClassesDemo.arrayListClassDemo();

	}
}
