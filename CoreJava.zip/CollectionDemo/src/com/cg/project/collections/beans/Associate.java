package com.cg.project.collections.beans;

import java.util.Comparator;

public class Associate implements Comparator<Associate>{
private int associateId;
private String firstName;
private String lastname;
private int basicSalary;

public Associate() {}

public Associate(int associateId, String firstName, String lastname, int basicSalary) {
	super();
	this.associateId = associateId;
	this.firstName = firstName;
	this.lastname = lastname;
	this.basicSalary = basicSalary;
}

public int getAssociateId() {
	return associateId;
}

public void setAssociateId(int associateId) {
	this.associateId = associateId;
}

public String getFirstName() {
	return firstName;
}

public void setFirstName(String firstName) {
	this.firstName = firstName;
}

public String getLastname() {
	return lastname;
}

public void setLastname(String lastname) {
	this.lastname = lastname;
}

public int getBasicSalary() {
	return basicSalary;
}

public void setBasicSalary(int basicSalary) {
	this.basicSalary = basicSalary;
}


@Override
public String toString() {
	return "Associate [associateId=" + associateId + ", firstName=" + firstName + ", lastname=" + lastname
			+ ", basicSalary=" + basicSalary + "]";
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Associate other = (Associate) obj;
	if (firstName == null) {
		if (other.firstName != null)
			return false;
	} else if (!firstName.equals(other.firstName))
		return false;
	return true;
}

public int compareTo(Associate o) {
	return this.firstName.compareTo(o.getFirstName());
}

@Override
public int compare(Associate o1, Associate o2) {
	return 0;
}

}
