package com.cg.project.collections.beans;

import java.util.ArrayList;
import java.util.Hashtable;

public class MapClassesDemo {
public static void hashtableClassWork() {
	Hashtable<Integer, Associate>associates=new Hashtable<>();
	associates.put(111,new Associate(111,"Debojyoti","Basu",60000));
	associates.put(114,new Associate(114,"Arnab","Pratihar",57000));
	associates.put(112,new Associate(112,"Daipayan","Guha",56000));
	associates.put(115,new Associate(115,"Rochita","Bagchi",55000));	
	associates.put(114,new Associate(114,"Shradhya","basu",57000));
	 Associate associate=associates.get(112);
	 associates.remove(112);
	 set<Integer>keys=associates.keySet();
	 for(Integer key: keys) {
		 System.out.println(associates.get(key));
	 }
	 ArrayList<Associate>associatelist=new ArrayList<>(associate)
}
}
